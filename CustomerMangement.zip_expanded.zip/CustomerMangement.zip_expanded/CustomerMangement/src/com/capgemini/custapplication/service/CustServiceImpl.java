package com.capgemini.custapplication.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.custapplication.bean.CustBean;
import com.capgemini.custapplication.dao.custDaoImpl;
import com.capgemini.custapplication.dao.ICustDAO;
import com.capgemini.custapplication.exception.CustException;

public class CustServiceImpl  
{
	
	custDaoImpl custDao;
	public String addCustDetails(CustBean cust) throws CustException {
		custDao=new custDaoImpl();	
		String custSeq;
		custSeq= custDao.addCustDetails(cust);
		return custSeq; 
	}
	/*public CustBean viewCustDetails(String custid) throws CustException {
		custDao=new custDaoImpl();
		CustBean bean=null;
		bean=custDao.viewCustDetails(custid);
		return bean;
	}*/
	public void viewCustDetails(int d,String email,String name) throws CustException
	{
		custDaoImpl custDao=new custDaoImpl();
		String user=Integer.toString(d);
		CustBean id;
		custDao.viewCustDetails(user,email,name);
		return;
	}

	public List<CustBean> retriveAll() throws CustException {
		 custDao=new custDaoImpl();
		List<CustBean> custList = null;
		custList=custDao.retriveAllDetails();
		return custList;
	}
	

	public void validatecust(CustBean bean) throws CustException
	{
		List<String> validationErrors = new ArrayList<String>();

		//Validating donor name
		if(!(isValidName(bean.getFullname()))) {
			validationErrors.add("\n customer Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		/*//Validating address
		if(!(isValidAddress(bean.getPdesc()))){
			validationErrors.add("\n Address Should Be Greater Than 5 Characters \n");
		}
		//Validating Phone Number
		if(!(isValidPhoneNumber(bean.getPno()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		//Validating Donation Amount
		if(!(isValidAmount(bean.getAge()))){
			validationErrors.add("\n Amount Should be a positive Number \n" );
		}*/
		
		if(!validationErrors.isEmpty())
			throw new CustException(validationErrors +"");
	}

	public boolean isValidName(String custName){
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(custName);
		return nameMatcher.matches();
	}
	public boolean isValidAddress(String address){
		return (address.length() > 6);
	}
	
	public boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[6-9]{1}[0-9]{9}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	public boolean validateCustId(String custId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(custId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}
}

	
	


