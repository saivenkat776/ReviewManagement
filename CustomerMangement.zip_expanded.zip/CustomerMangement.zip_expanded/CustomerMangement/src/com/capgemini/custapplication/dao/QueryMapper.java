package com.capgemini.custapplication.dao;

public interface QueryMapper {
	
	public static final String RETRIVE_ALL_QUERY="SELECT CUSTID,EMAIL,FULLNAME,CITY,COUNTRY,REGESTRATIONDATE FROM CUSTOMER";
	public static final String UPDATE_CUST_DETAILS_QUERY="UPDATE CUSTOMER SET EMAIL = ?,CITY=? WHERE custid =?";
	public static final String INSERT_QUERY="INSERT INTO CUSTOMER VALUES(custid_sequence.NEXTVAL,?,?,?,?,?,?,?,?,?,SYSDATE)";
	public static final String CUSTID_QUERY_SEQUENCE="SELECT custid_sequence.CURRVAL FROM DUAL";
	
}